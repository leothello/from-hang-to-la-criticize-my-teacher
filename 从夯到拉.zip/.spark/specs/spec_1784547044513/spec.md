# 技术方案

## 开发元信息
- 开发模式: 全栈应用
- 涉及层级: [数据库, 服务端, 前端]

## 页面路由与导航

### 页面路由
- `/` - 锐评主页面（五档排行 + 待评分区 + 添加人物入口）
- `/person/:id` - 人物详情页（头像管理 + 简介管理 + 评分操作）

### 导航设计
- 导航机制：页面路由
- 导航项：
  - 首页（Logo/标题点击返回主页）

## 业务组件

| 组件 | 来源 | 关联页面 | 对应功能点 |
|------|------|---------|-----------|
| Dialog | shadcn/ui 内置 | 锐评主页面、人物详情页 | 添加人物弹窗、评分弹窗 |
| Button | shadcn/ui 内置 | 全部页面 | 操作按钮 |
| Input | shadcn/ui 内置 | 锐评主页面 | 姓名输入 |
| Textarea | shadcn/ui 内置 | 锐评主页面、人物详情页 | 简介输入 |
| Badge | shadcn/ui 内置 | 锐评主页面、人物详情页 | 档位标签、待评分角标 |
| Avatar | shadcn/ui 内置 | 锐评主页面、人物详情页 | 人物头像展示 |
| Tabs | shadcn/ui 内置 | 人物详情页 | 头像/简介切换 |
| ScrollArea | shadcn/ui 内置 | 锐评主页面 | 档位区域横向滚动 |

## 数据模型

### 数据库设计

#### 人物表（person）
用途：存储人物基本信息与评分汇总数据。
核心字段：
- name: varchar (姓名，唯一索引，用于去重)
- avg_score: numeric (平均评分，冗余字段，范围 1-5，评分人数为0时为null)
- rating_count: integer (评分人数，默认0)
- is_pending: boolean (是否待评分，默认true，评分人数>0时为false)
关联关系：与头像表、简介表、评分表均为一对多关系

#### 人物头像表（person_avatar）
用途：存储某个人物的多张头像照片及其点赞数。
核心字段：
- person_id: uuid (关联人物ID，外键)
- image_url: text (头像图片URL，来自文件存储服务)
- like_count: integer (点赞数，默认0)
关联关系：belongs to person

#### 人物简介表（person_bio）
用途：存储某个人物的多条简介及其点赞数。
核心字段：
- person_id: uuid (关联人物ID，外键)
- content: varchar (简介内容，最多200字)
- like_count: integer (点赞数，默认0)
关联关系：belongs to person

#### 评分记录表（person_rating）
用途：存储每次评分记录，用于计算平均分。
核心字段：
- person_id: uuid (关联人物ID，外键)
- score: integer (评分值，1-5 对应 拉/NPC/人上人/顶级/夯)
- rater_fingerprint: varchar (评分者指纹，用于简单去重，可选)
关联关系：belongs to person

## 业务模型

### API 设计

#### 锐评主页面相关
**页面路径**: /
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 展示五档人物列表 | API | GET /api/persons/tiered |
| 展示待评分人物 | API | GET /api/persons/pending |
| 添加新人物 | API | POST /api/persons |
| 为人物评分 | API | POST /api/persons/:id/rate |
| 上传头像照片 | 平台能力 + API | 前端使用文件存储服务上传，POST /api/persons/:id/avatars 关联 |

**所需 API**:

```typescript
// 获取按档位分组的人物列表 [领域模型: PersonModel] [对应页面功能: 五档排行展示]
GET /api/persons/tiered
Response: {
  tiers: {
    tier: number; // 1-5, 1=拉, 5=夯
    tierName: string;
    persons: Array<{
      id: string;
      name: string;
      avgScore: number | null;
      ratingCount: number;
      avatarUrl: string | null; // 点赞最高的头像
    }>;
  }[];
  pending: Array<{
    id: string;
    name: string;
    avatarUrl: string | null;
  }>;
}
```

```typescript
// 添加新人物 [领域模型: PersonModel] [对应页面功能: 添加新人物]
POST /api/persons
Request: {
  name: string;      // 必填
  bio: string;       // 必填，首条简介，最多200字
  imageUrl?: string; // 选填，首张头像URL
}
Response: {
  id: string;
  name: string;
  isPending: true;
}
// 错误：409 { message: "该人物已存在，不能重复添加" }
```

```typescript
// 为人物评分 [领域模型: PersonRatingModel] [对应页面功能: 为人物评分分档]
POST /api/persons/:id/rate
Request: {
  score: number; // 1-5
}
Response: {
  id: string;
  avgScore: number;
  ratingCount: number;
  tier: number; // 1-5，四舍五入后的档位
}
```

#### 人物详情页相关
**页面路径**: /person/:id
**功能全景**：
| 功能 | 实现方式 | 说明 |
|------|----------|------|
| 获取人物详情 | API | GET /api/persons/:id |
| 获取人物头像列表 | API | GET /api/persons/:id/avatars |
| 获取人物简介列表 | API | GET /api/persons/:id/bios |
| 上传新头像 | 平台能力 + API | 前端上传文件，API 关联保存 |
| 添加新简介 | API | POST /api/persons/:id/bios |
| 点赞头像 | API | POST /api/persons/:id/avatars/:avatarId/like |
| 点赞简介 | API | POST /api/persons/:id/bios/:bioId/like |
| 评分 | API | POST /api/persons/:id/rate |

**所需 API**:

```typescript
// 获取人物详情 [领域模型: PersonModel] [对应页面功能: 查看人物详情]
GET /api/persons/:id
Response: {
  id: string;
  name: string;
  avgScore: number | null;
  ratingCount: number;
  tier: number | null; // 四舍五入后的档位，null 表示待评分
  isPending: boolean;
  defaultAvatar: { id: string; imageUrl: string; likeCount: number; } | null;
  defaultBio: { id: string; content: string; likeCount: number; } | null;
}
```

```typescript
// 获取人物头像列表 [领域模型: PersonAvatarModel] [对应页面功能: 上传人物头像照片]
GET /api/persons/:id/avatars
Response: {
  items: Array<{
    id: string;
    imageUrl: string;
    likeCount: number;
    createdAt: string;
  }>;
}
// 按点赞数降序、创建时间升序排列
```

```typescript
// 获取人物简介列表 [领域模型: PersonBioModel] [对应页面功能: 添加人物简介]
GET /api/persons/:id/bios
Response: {
  items: Array<{
    id: string;
    content: string;
    likeCount: number;
    createdAt: string;
  }>;
}
// 按点赞数降序、创建时间升序排列
```

```typescript
// 上传新头像 [领域模型: PersonAvatarModel] [对应页面功能: 上传人物头像照片]
POST /api/persons/:id/avatars
Request: {
  imageUrl: string; // 文件存储服务返回的URL
}
Response: {
  id: string;
  imageUrl: string;
  likeCount: number;
}
// 业务规则：超过10张时自动挤掉点赞最少的，点赞相同挤掉最早的
```

```typescript
// 添加新简介 [领域模型: PersonBioModel] [对应页面功能: 添加人物简介]
POST /api/persons/:id/bios
Request: {
  content: string; // 最多200字
}
Response: {
  id: string;
  content: string;
  likeCount: number;
}
// 业务规则：超过10条时自动挤掉点赞最少的，点赞相同挤掉最早的
```

```typescript
// 点赞头像 [领域模型: PersonAvatarModel] [对应页面功能: 上传人物头像照片]
POST /api/persons/:id/avatars/:avatarId/like
Response: {
  id: string;
  likeCount: number;
}
```

```typescript
// 点赞简介 [领域模型: PersonBioModel] [对应页面功能: 添加人物简介]
POST /api/persons/:id/bios/:bioId/like
Response: {
  id: string;
  likeCount: number;
}
```
