import { Injectable, Logger, NotFoundException, ConflictException } from '@nestjs/common';
import { eq, desc, asc, and, inArray } from 'drizzle-orm';
import { DRIZZLE_DATABASE, type PostgresJsDatabase } from '@lark-apaas/fullstack-nestjs-core';
import { Inject } from '@nestjs/common';

import {
  person,
  personAvatar,
  personBio,
  personRating,
} from '@server/database/schema';
import {
  SCORE_TIER_MAP,
  type TierScore,
  type TierName,
  type TieredListResponse,
  type TierGroup,
  type TieredPerson,
  type PersonDetailResponse,
  type PersonAvatar,
  type PersonBio,
  type CreatePersonResponse,
  type RatePersonResponse,
  type AvatarListResponse,
  type BioListResponse,
  type CreateAvatarResponse,
  type CreateBioResponse,
  type LikeResponse,
} from '@shared/api.interface';

@Injectable()
export class PersonService {
  private readonly logger = new Logger(PersonService.name);

  constructor(
    @Inject(DRIZZLE_DATABASE) private readonly db: PostgresJsDatabase,
  ) {}

  /**
   * 将 numeric 字符串转为 number，null 保持 null
   */
  private toNumber(value: string | number | null): number | null {
    if (value === null || value === undefined) return null;
    return typeof value === 'number' ? value : Number(value);
  }

  /**
   * 根据平均分计算档位（四舍五入）
   */
  private calcTier(avgScore: number | null): TierScore | null {
    if (avgScore === null || avgScore === undefined) return null;
    const rounded = Math.round(avgScore);
    if (rounded < 1) return 1 as TierScore;
    if (rounded > 5) return 5 as TierScore;
    return rounded as TierScore;
  }

  private tierNameOf(tier: TierScore | null): TierName | null {
    if (tier === null) return null;
    return SCORE_TIER_MAP[tier];
  }

  /**
   * 将 DB 行映射为 PersonAvatar 接口类型
   */
  private mapAvatar(row: {
    id: string;
    personId: string;
    imageUrl: string;
    likeCount: number;
    createdAt: Date;
  }): PersonAvatar {
    return {
      id: row.id,
      personId: row.personId,
      imageUrl: row.imageUrl,
      likeCount: row.likeCount,
      createdAt: row.createdAt.toISOString(),
    };
  }

  /**
   * 将 DB 行映射为 PersonBio 接口类型
   */
  private mapBio(row: {
    id: string;
    personId: string;
    content: string;
    likeCount: number;
    createdAt: Date;
  }): PersonBio {
    return {
      id: row.id,
      personId: row.personId,
      content: row.content,
      likeCount: row.likeCount,
      createdAt: row.createdAt.toISOString(),
    };
  }

  /**
   * 1. 获取按档位分组的人物列表
   */
  async getTieredList(): Promise<TieredListResponse> {
    this.logger.log('获取档位人物列表');

    // 查询所有非待评分人物
    const activePersons = await this.db
      .select()
      .from(person)
      .where(eq(person.isPending, false));

    // 查询所有待评分人物
    const pendingPersons = await this.db
      .select()
      .from(person)
      .where(eq(person.isPending, true));

    // 收集所有人物 id，批量查头像（避免 N+1）
    const allPersonIds: string[] = [
      ...activePersons.map((p) => p.id),
      ...pendingPersons.map((p) => p.id),
    ];

    // 每个人物取点赞最高的头像
    let topAvatarMap = new Map<string, string>();
    if (allPersonIds.length > 0) {
      const avatars = await this.db
        .select()
        .from(personAvatar)
        .where(inArray(personAvatar.personId, allPersonIds))
        .orderBy(desc(personAvatar.likeCount), asc(personAvatar.createdAt));

      // 每个人物只保留第一个（点赞最高）
      for (const a of avatars) {
        if (!topAvatarMap.has(a.personId)) {
          topAvatarMap.set(a.personId, a.imageUrl);
        }
      }
    }

    const toTieredPerson = (p: typeof activePersons[number]): TieredPerson => ({
      id: p.id,
      name: p.name,
      avgScore: this.toNumber(p.avgScore),
      ratingCount: p.ratingCount,
      avatarUrl: topAvatarMap.get(p.id) ?? null,
    });

    // 按档位分组
    const tierMap = new Map<number, TieredPerson[]>();
    for (const p of activePersons) {
      const avg = this.toNumber(p.avgScore);
      const tier = this.calcTier(avg);
      if (tier === null) continue;
      if (!tierMap.has(tier)) tierMap.set(tier, []);
      tierMap.get(tier)!.push(toTieredPerson(p));
    }

    // 构建五档，从高到低
    const tiers: TierGroup[] = [];
    for (let t = 5; t >= 1; t--) {
      const tierScore = t as TierScore;
      tiers.push({
        tier: tierScore,
        tierName: SCORE_TIER_MAP[tierScore],
        persons: tierMap.get(t) ?? [],
      });
    }

    const pending: TieredPerson[] = pendingPersons.map(toTieredPerson);

    return { tiers, pending };
  }

  /**
   * 2. 获取人物详情
   */
  async getPersonDetail(id: string): Promise<PersonDetailResponse> {
    this.logger.log(`获取人物详情: ${id}`);

    const persons = await this.db.select().from(person).where(eq(person.id, id));
    if (persons.length === 0) {
      throw new NotFoundException('人物不存在');
    }
    const p = persons[0];

    // 点赞最高的头像
    const topAvatars = await this.db
      .select()
      .from(personAvatar)
      .where(eq(personAvatar.personId, id))
      .orderBy(desc(personAvatar.likeCount), asc(personAvatar.createdAt))
      .limit(1);
    const defaultAvatar: PersonAvatar | null =
      topAvatars.length > 0 ? this.mapAvatar(topAvatars[0]) : null;

    // 点赞最高的简介
    const topBios = await this.db
      .select()
      .from(personBio)
      .where(eq(personBio.personId, id))
      .orderBy(desc(personBio.likeCount), asc(personBio.createdAt))
      .limit(1);
    const defaultBio: PersonBio | null =
      topBios.length > 0 ? this.mapBio(topBios[0]) : null;

    const avgScore = this.toNumber(p.avgScore);
    const tier = this.calcTier(avgScore);

    return {
      id: p.id,
      name: p.name,
      avgScore,
      ratingCount: p.ratingCount,
      tier,
      tierName: this.tierNameOf(tier),
      isPending: p.isPending,
      defaultAvatar,
      defaultBio,
    };
  }

  /**
   * 3. 创建新人物
   */
  async createPerson(dto: {
    name: string;
    bio: string;
    imageUrl?: string;
  }): Promise<CreatePersonResponse> {
    this.logger.log(`创建人物: ${dto.name}`);

    // 姓名去重
    const existing = await this.db
      .select()
      .from(person)
      .where(eq(person.name, dto.name));
    if (existing.length > 0) {
      throw new ConflictException('该人物已存在，不能重复添加');
    }

    // 事务：创建人物 + 第一条简介 + 第一张头像（如有）
    const result = await this.db.transaction(async (tx) => {
      const inserted = await tx
        .insert(person)
        .values({
          name: dto.name,
          avgScore: null,
          ratingCount: 0,
          isPending: true,
        })
        .returning({ id: person.id, name: person.name, isPending: person.isPending });

      if (inserted.length === 0) {
        throw new Error('创建人物失败');
      }
      const newPerson = inserted[0];

      // 创建第一条简介
      await tx.insert(personBio).values({
        personId: newPerson.id,
        content: dto.bio,
        likeCount: 0,
      });

      // 创建第一张头像（如有）
      if (dto.imageUrl && dto.imageUrl.trim().length > 0) {
        await tx.insert(personAvatar).values({
          personId: newPerson.id,
          imageUrl: dto.imageUrl,
          likeCount: 0,
        });
      }

      return newPerson;
    });

    return {
      id: result.id,
      name: result.name,
      isPending: result.isPending,
    };
  }

  /**
   * 4. 为人物评分
   */
  async ratePerson(id: string, score: number): Promise<RatePersonResponse> {
    this.logger.log(`人物 ${id} 评分: ${score}`);

    const result = await this.db.transaction(async (tx) => {
      // 查询当前人物
      const persons = await tx.select().from(person).where(eq(person.id, id));
      if (persons.length === 0) {
        throw new NotFoundException('人物不存在');
      }
      const p = persons[0];

      // 插入评分记录
      await tx.insert(personRating).values({
        personId: id,
        score,
      });

      // 计算新的平均分和人数
      const oldAvg = this.toNumber(p.avgScore) ?? 0;
      const oldCount = p.ratingCount;
      const newCount = oldCount + 1;
      const newAvg = (oldAvg * oldCount + score) / newCount;

      // 更新人物
      const updated = await tx
        .update(person)
        .set({
          avgScore: newAvg.toString(),
          ratingCount: newCount,
          isPending: false,
        })
        .where(eq(person.id, id))
        .returning({ id: person.id });

      if (updated.length === 0) {
        throw new Error('更新人物评分失败');
      }

      const tier = this.calcTier(newAvg)!;

      return {
        id,
        avgScore: newAvg,
        ratingCount: newCount,
        tier,
        tierName: SCORE_TIER_MAP[tier],
      };
    });

    return result;
  }

  /**
   * 5. 获取人物头像列表
   */
  async getAvatars(personId: string): Promise<AvatarListResponse> {
    // 校验人物存在
    const persons = await this.db.select().from(person).where(eq(person.id, personId));
    if (persons.length === 0) {
      throw new NotFoundException('人物不存在');
    }

    const avatars = await this.db
      .select()
      .from(personAvatar)
      .where(eq(personAvatar.personId, personId))
      .orderBy(desc(personAvatar.likeCount), asc(personAvatar.createdAt));

    return {
      items: avatars.map(this.mapAvatar),
    };
  }

  /**
   * 6. 上传新头像
   */
  async createAvatar(
    personId: string,
    imageUrl: string,
  ): Promise<CreateAvatarResponse> {
    this.logger.log(`人物 ${personId} 上传新头像`);

    const result = await this.db.transaction(async (tx) => {
      // 校验人物存在
      const persons = await tx.select().from(person).where(eq(person.id, personId));
      if (persons.length === 0) {
        throw new NotFoundException('人物不存在');
      }

      // 插入新头像
      const inserted = await tx
        .insert(personAvatar)
        .values({
          personId,
          imageUrl,
          likeCount: 0,
        })
        .returning({
          id: personAvatar.id,
          imageUrl: personAvatar.imageUrl,
          likeCount: personAvatar.likeCount,
        });

      if (inserted.length === 0) {
        throw new Error('创建头像失败');
      }

      // 检查是否超过 10 张，超过则删除点赞最低且创建最早的
      const allAvatars = await tx
        .select({ id: personAvatar.id })
        .from(personAvatar)
        .where(eq(personAvatar.personId, personId));

      if (allAvatars.length > 10) {
        const oldest = await tx
          .select({ id: personAvatar.id })
          .from(personAvatar)
          .where(eq(personAvatar.personId, personId))
          .orderBy(asc(personAvatar.likeCount), asc(personAvatar.createdAt))
          .limit(1);

        if (oldest.length > 0) {
          const deleted = await tx
            .delete(personAvatar)
            .where(eq(personAvatar.id, oldest[0].id))
            .returning({ id: personAvatar.id });
          if (deleted.length === 0) {
            throw new Error('删除多余头像失败');
          }
          this.logger.log(`删除多余头像: ${oldest[0].id}`);
        }
      }

      return inserted[0];
    });

    return {
      id: result.id,
      imageUrl: result.imageUrl,
      likeCount: result.likeCount,
    };
  }

  /**
   * 7. 点赞头像
   */
  async likeAvatar(personId: string, avatarId: string): Promise<LikeResponse> {
    this.logger.log(`点赞头像 ${avatarId}`);

    // 校验人物存在
    const persons = await this.db.select().from(person).where(eq(person.id, personId));
    if (persons.length === 0) {
      throw new NotFoundException('人物不存在');
    }

    // 校验头像存在且属于该人物
    const avatars = await this.db
      .select()
      .from(personAvatar)
      .where(
        and(eq(personAvatar.id, avatarId), eq(personAvatar.personId, personId)),
      );
    if (avatars.length === 0) {
      throw new NotFoundException('头像不存在');
    }

    const updated = await this.db
      .update(personAvatar)
      .set({ likeCount: avatars[0].likeCount + 1 })
      .where(eq(personAvatar.id, avatarId))
      .returning({ id: personAvatar.id, likeCount: personAvatar.likeCount });

    if (updated.length === 0) {
      throw new Error('点赞失败');
    }

    return {
      id: updated[0].id,
      likeCount: updated[0].likeCount,
    };
  }

  /**
   * 8. 获取人物简介列表
   */
  async getBios(personId: string): Promise<BioListResponse> {
    // 校验人物存在
    const persons = await this.db.select().from(person).where(eq(person.id, personId));
    if (persons.length === 0) {
      throw new NotFoundException('人物不存在');
    }

    const bios = await this.db
      .select()
      .from(personBio)
      .where(eq(personBio.personId, personId))
      .orderBy(desc(personBio.likeCount), asc(personBio.createdAt));

    return {
      items: bios.map(this.mapBio),
    };
  }

  /**
   * 9. 添加新简介
   */
  async createBio(
    personId: string,
    content: string,
  ): Promise<CreateBioResponse> {
    this.logger.log(`人物 ${personId} 添加新简介`);

    const result = await this.db.transaction(async (tx) => {
      // 校验人物存在
      const persons = await tx.select().from(person).where(eq(person.id, personId));
      if (persons.length === 0) {
        throw new NotFoundException('人物不存在');
      }

      // 插入新简介
      const inserted = await tx
        .insert(personBio)
        .values({
          personId,
          content,
          likeCount: 0,
        })
        .returning({
          id: personBio.id,
          content: personBio.content,
          likeCount: personBio.likeCount,
        });

      if (inserted.length === 0) {
        throw new Error('创建简介失败');
      }

      // 检查是否超过 10 条，超过则删除点赞最低且创建最早的
      const allBios = await tx
        .select({ id: personBio.id })
        .from(personBio)
        .where(eq(personBio.personId, personId));

      if (allBios.length > 10) {
        const oldest = await tx
          .select({ id: personBio.id })
          .from(personBio)
          .where(eq(personBio.personId, personId))
          .orderBy(asc(personBio.likeCount), asc(personBio.createdAt))
          .limit(1);

        if (oldest.length > 0) {
          const deleted = await tx
            .delete(personBio)
            .where(eq(personBio.id, oldest[0].id))
            .returning({ id: personBio.id });
          if (deleted.length === 0) {
            throw new Error('删除多余简介失败');
          }
          this.logger.log(`删除多余简介: ${oldest[0].id}`);
        }
      }

      return inserted[0];
    });

    return {
      id: result.id,
      content: result.content,
      likeCount: result.likeCount,
    };
  }

  /**
   * 10. 点赞简介
   */
  async likeBio(personId: string, bioId: string): Promise<LikeResponse> {
    this.logger.log(`点赞简介 ${bioId}`);

    // 校验人物存在
    const persons = await this.db.select().from(person).where(eq(person.id, personId));
    if (persons.length === 0) {
      throw new NotFoundException('人物不存在');
    }

    // 校验简介存在且属于该人物
    const bios = await this.db
      .select()
      .from(personBio)
      .where(and(eq(personBio.id, bioId), eq(personBio.personId, personId)));
    if (bios.length === 0) {
      throw new NotFoundException('简介不存在');
    }

    const updated = await this.db
      .update(personBio)
      .set({ likeCount: bios[0].likeCount + 1 })
      .where(eq(personBio.id, bioId))
      .returning({ id: personBio.id, likeCount: personBio.likeCount });

    if (updated.length === 0) {
      throw new Error('点赞失败');
    }

    return {
      id: updated[0].id,
      likeCount: updated[0].likeCount,
    };
  }
}
