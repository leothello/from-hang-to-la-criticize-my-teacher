import { Controller, Get, Post, Body, Param } from '@nestjs/common';

import { PersonService } from './person.service';
import { CreatePersonDto } from './dto/create-person.dto';
import { RatePersonDto } from './dto/rate-person.dto';
import { CreateAvatarDto } from './dto/create-avatar.dto';
import { CreateBioDto } from './dto/create-bio.dto';
import type {
  TieredListResponse,
  PersonDetailResponse,
  CreatePersonResponse,
  RatePersonResponse,
  AvatarListResponse,
  BioListResponse,
  CreateAvatarResponse,
  CreateBioResponse,
  LikeResponse,
} from '@shared/api.interface';

@Controller('api/persons')
export class PersonController {
  constructor(private readonly personService: PersonService) {}

  // 1. 静态路由在前：获取按档位分组的人物列表
  @Get('tiered')
  async getTieredList(): Promise<TieredListResponse> {
    return this.personService.getTieredList();
  }

  // 2. 获取人物详情（动态路由在后）
  @Get(':id')
  async getPersonDetail(@Param('id') id: string): Promise<PersonDetailResponse> {
    return this.personService.getPersonDetail(id);
  }

  // 3. 创建新人物
  @Post()
  async createPerson(@Body() dto: CreatePersonDto): Promise<CreatePersonResponse> {
    return this.personService.createPerson(dto);
  }

  // 4. 为人物评分
  @Post(':id/rate')
  async ratePerson(
    @Param('id') id: string,
    @Body() dto: RatePersonDto,
  ): Promise<RatePersonResponse> {
    return this.personService.ratePerson(id, dto.score);
  }

  // 5. 获取人物头像列表
  @Get(':id/avatars')
  async getAvatars(@Param('id') id: string): Promise<AvatarListResponse> {
    return this.personService.getAvatars(id);
  }

  // 6. 上传新头像
  @Post(':id/avatars')
  async createAvatar(
    @Param('id') id: string,
    @Body() dto: CreateAvatarDto,
  ): Promise<CreateAvatarResponse> {
    return this.personService.createAvatar(id, dto.imageUrl);
  }

  // 7. 点赞头像
  @Post(':id/avatars/:avatarId/like')
  async likeAvatar(
    @Param('id') id: string,
    @Param('avatarId') avatarId: string,
  ): Promise<LikeResponse> {
    return this.personService.likeAvatar(id, avatarId);
  }

  // 8. 获取人物简介列表
  @Get(':id/bios')
  async getBios(@Param('id') id: string): Promise<BioListResponse> {
    return this.personService.getBios(id);
  }

  // 9. 添加新简介
  @Post(':id/bios')
  async createBio(
    @Param('id') id: string,
    @Body() dto: CreateBioDto,
  ): Promise<CreateBioResponse> {
    return this.personService.createBio(id, dto.content);
  }

  // 10. 点赞简介
  @Post(':id/bios/:bioId/like')
  async likeBio(
    @Param('id') id: string,
    @Param('bioId') bioId: string,
  ): Promise<LikeResponse> {
    return this.personService.likeBio(id, bioId);
  }
}
