import { IsString, IsNotEmpty, MaxLength } from 'class-validator';

export class CreateBioDto {
  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  content!: string;
}
