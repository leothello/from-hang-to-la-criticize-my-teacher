import { IsInt, Min, Max } from 'class-validator';

export class RatePersonDto {
  @IsInt()
  @Min(1)
  @Max(5)
  score!: number;
}
