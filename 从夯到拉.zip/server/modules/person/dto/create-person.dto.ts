import { IsString, IsNotEmpty, MaxLength, IsOptional } from 'class-validator';

export class CreatePersonDto {
  @IsString()
  @IsNotEmpty()
  name!: string;

  @IsString()
  @IsNotEmpty()
  @MaxLength(200)
  bio!: string;

  @IsOptional()
  @IsString()
  imageUrl?: string;
}
