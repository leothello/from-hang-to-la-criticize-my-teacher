import { IsString, IsNotEmpty } from 'class-validator';

export class CreateAvatarDto {
  @IsString()
  @IsNotEmpty()
  imageUrl!: string;
}
