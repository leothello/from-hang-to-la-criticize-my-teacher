import { useState } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';

import { ratePerson } from '@client/src/api/person';
import {
  TIER_SCORE_MAP,
  SCORE_TIER_MAP,
  type TierScore,
  type TieredPerson,
} from '@shared/api.interface';

interface RateDialogProps {
  person: TieredPerson | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

const TIER_OPTIONS: Array<{
  score: TierScore;
  name: string;
  subtitle: string;
  bgClass: string;
  textClass: string;
}> = [
  {
    score: 5,
    name: '夯',
    subtitle: '神中神',
    bgClass: 'bg-tier-s',
    textClass: 'text-tier-s-foreground',
  },
  {
    score: 4,
    name: '顶级',
    subtitle: '大牛',
    bgClass: 'bg-tier-a',
    textClass: 'text-tier-a-foreground',
  },
  {
    score: 3,
    name: '人上人',
    subtitle: '还行',
    bgClass: 'bg-tier-b',
    textClass: 'text-tier-b-foreground',
  },
  {
    score: 2,
    name: 'NPC',
    subtitle: '路人',
    bgClass: 'bg-tier-c',
    textClass: 'text-tier-c-foreground',
  },
  {
    score: 1,
    name: '拉',
    subtitle: '答辩',
    bgClass: 'bg-tier-d',
    textClass: 'text-tier-d-foreground',
  },
];

const RateDialog = ({ person, open, onOpenChange, onSuccess }: RateDialogProps) => {
  const [selectedScore, setSelectedScore] = useState<TierScore | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!person || !selectedScore) {
      toast.error('请选择一个档位');
      return;
    }

    setSubmitting(true);
    try {
      const result = await ratePerson(person.id, { score: selectedScore });
      toast.success(
        `评分成功！${person.name} 已归入「${result.tierName}」档`,
      );
      onOpenChange(false);
      setSelectedScore(null);
      onSuccess();
    } catch (error) {
      logger.error(`评分失败: ${person?.id}`, error);
      toast.error('评分失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    if (submitting) return;
    onOpenChange(false);
    setSelectedScore(null);
  };

  if (!person) return null;

  return (
    <Dialog open={open} onOpenChange={handleCancel}>
      <DialogContent className="border-2 border-foreground shadow-hard-lg rounded-none bg-background max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-heading font-black text-xl">
            为 {person.name} 评分
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div className="grid grid-cols-5 gap-2">
            {TIER_OPTIONS.map((tier) => {
              const isSelected = selectedScore === tier.score;
              return (
                <button
                  key={tier.score}
                  type="button"
                  onClick={() => setSelectedScore(tier.score)}
                  className={`
                    ${tier.bgClass} ${tier.textClass}
                    border-2 border-foreground
                    flex flex-col items-center justify-center
                    py-3 px-1
                    transition-all duration-150
                    ${isSelected
                      ? 'shadow-hard -translate-y-1 border-4'
                      : 'shadow-hard-sm hover:shadow-hard hover:-translate-y-0.5'
                    }
                  `}
                >
                  <span className="font-heading font-black text-lg leading-none">
                    {tier.name}
                  </span>
                  <span className="text-[10px] italic mt-1 opacity-80">
                    {tier.subtitle}
                  </span>
                  <span className="text-xs font-mono mt-1">{tier.score}分</span>
                </button>
              );
            })}
          </div>

          <div className="text-center">
            <Link
              to={`/person/${person.id}`}
              className="text-sm text-muted-foreground underline hover:text-foreground inline-block"
            >
              查看详情 →
            </Link>
          </div>
        </div>

        <DialogFooter className="flex flex-row-reverse sm:justify-end gap-2">
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={submitting || !selectedScore}
            className="bg-primary text-primary-foreground border-2 border-foreground rounded-none shadow-hard-sm hover:shadow-hard hover:-translate-y-0.5 transition-all"
          >
            {submitting ? '提交中...' : '确认评分'}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            disabled={submitting}
            className="border-2 border-foreground rounded-none hover:bg-accent"
          >
            取消
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RateDialog;
