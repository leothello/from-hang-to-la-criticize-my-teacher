import { useState, useRef } from 'react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import { Button } from '@client/src/components/ui/button';
import { Input } from '@client/src/components/ui/input';
import { Textarea } from '@client/src/components/ui/textarea';
import { Image } from '@client/src/components/ui/image';

import { createPerson } from '@client/src/api/person';

interface AddPersonDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSuccess: () => void;
}

const MAX_FILE_SIZE = 1 * 1024 * 1024; // 1MB
const MAX_BIO_LENGTH = 200;

const AddPersonDialog = ({ open, onOpenChange, onSuccess }: AddPersonDialogProps) => {
  const [name, setName] = useState('');
  const [bio, setBio] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const uploadedUrlRef = useRef<string | null>(null);

  const resetForm = () => {
    setName('');
    setBio('');
    setPreviewUrl(null);
    setUploading(false);
    setSubmitting(false);
    uploadedUrlRef.current = null;
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > MAX_FILE_SIZE) {
      toast.error('照片大小不能超过 1MB');
      if (fileInputRef.current) fileInputRef.current.value = '';
      return;
    }

    // 显示本地预览
    const localPreview = URL.createObjectURL(file);
    setPreviewUrl(localPreview);
    setUploading(true);

    try {
      const dataloom = getDataloom();
      const result = await dataloom.uploadFile(file);
      uploadedUrlRef.current = result.download_url ?? null;
      logger.log('照片上传成功');
    } catch (error) {
      logger.error('照片上传失败', error);
      toast.error('照片上传失败，请重试');
      setPreviewUrl(null);
      uploadedUrlRef.current = null;
    } finally {
      setUploading(false);
    }
  };

  const handleSubmit = async () => {
    if (!name.trim()) {
      toast.error('请填写姓名');
      return;
    }
    if (!bio.trim()) {
      toast.error('请填写简介');
      return;
    }
    if (uploading) {
      toast.error('照片上传中，请稍候');
      return;
    }

    setSubmitting(true);
    try {
      await createPerson({
        name: name.trim(),
        bio: bio.trim(),
        imageUrl: uploadedUrlRef.current ?? undefined,
      });
      toast.success('人物添加成功，已进入待评分区');
      onOpenChange(false);
      resetForm();
      onSuccess();
    } catch (error) {
      logger.error('添加人物失败', error);
      toast.error('添加失败，请重试');
    } finally {
      setSubmitting(false);
    }
  };

  const handleCancel = () => {
    if (submitting) return;
    onOpenChange(false);
    resetForm();
  };

  return (
    <Dialog open={open} onOpenChange={handleCancel}>
      <DialogContent className="border-2 border-foreground shadow-hard-lg rounded-none bg-background max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading font-black text-xl">
            添加新人物
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-medium">
              姓名 <span className="text-destructive">*</span>
            </label>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="请填写人物的真实姓名"
              className="border-2 border-foreground rounded-none h-10 focus-visible:ring-0 focus-visible:border-foreground"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-sm font-medium">照片（选填）</label>
            <div className="flex items-start gap-3">
              {previewUrl ? (
                <div className="relative w-16 h-16 border-2 border-foreground overflow-hidden">
                  <Image
                    src={previewUrl}
                    alt="预览"
                    width={64}
                    height={64}
                    className="w-full h-full object-cover"
                  />
                  {uploading && (
                    <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white text-xs">
                      上传中
                    </div>
                  )}
                </div>
              ) : (
                <div className="w-16 h-16 border-2 border-foreground border-dashed flex items-center justify-center text-muted-foreground text-xs">
                  无
                </div>
              )}
              <div className="flex flex-col gap-1">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  disabled={uploading}
                  className="border-2 border-foreground rounded-none hover:bg-accent"
                >
                  选择照片
                </Button>
                <span className="text-xs text-muted-foreground">
                  照片大小不超过 1MB
                </span>
              </div>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">
                简介 <span className="text-destructive">*</span>
              </label>
              <span className="text-xs text-muted-foreground font-mono">
                {bio.length}/{MAX_BIO_LENGTH}
              </span>
            </div>
            <Textarea
              value={bio}
              onChange={(e) => {
                if (e.target.value.length <= MAX_BIO_LENGTH) {
                  setBio(e.target.value);
                }
              }}
              placeholder="请撰写一段简介"
              rows={4}
              className="border-2 border-foreground rounded-none resize-none focus-visible:ring-0 focus-visible:border-foreground"
            />
          </div>
        </div>

        <DialogFooter className="flex flex-row-reverse sm:justify-end gap-2">
          <Button
            type="button"
            onClick={handleSubmit}
            disabled={submitting || uploading}
            className="bg-primary text-primary-foreground border-2 border-foreground rounded-none shadow-hard-sm hover:shadow-hard hover:-translate-y-0.5 transition-all"
          >
            {submitting ? '提交中...' : '确定'}
          </Button>
          <Button
            type="button"
            variant="outline"
            onClick={handleCancel}
            disabled={submitting}
            className="border-2 border-foreground rounded-none hover:bg-accent"
          >
            取消
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddPersonDialog;
