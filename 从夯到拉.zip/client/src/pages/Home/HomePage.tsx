import { useState, useEffect, useCallback } from 'react';
import { toast, Toaster } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { Plus } from 'lucide-react';

import { Button } from '@client/src/components/ui/button';
import TierBand from './TierBand';
import PersonCard from './PersonCard';
import AddPersonDialog from './AddPersonDialog';
import RateDialog from './RateDialog';

import { getTieredList } from '@client/src/api/person';
import type {
  TieredListResponse,
  TierGroup,
  TieredPerson,
} from '@shared/api.interface';

const TIER_META: Record<number, { subtitle: string; emoji: string }> = {
  5: { subtitle: '神中神', emoji: '👑' },
  4: { subtitle: '大牛', emoji: '💎' },
  3: { subtitle: '还行', emoji: '👍' },
  2: { subtitle: '路人', emoji: '🧑' },
  1: { subtitle: '答辩', emoji: '💩' },
};

const TIER_ORDER: number[] = [5, 4, 3, 2, 1];

const HomePage = () => {
  const [loading, setLoading] = useState(true);
  const [tierData, setTierData] = useState<TieredListResponse | null>(null);
  const [addOpen, setAddOpen] = useState(false);
  const [rateOpen, setRateOpen] = useState(false);
  const [ratePerson, setRatePerson] = useState<TieredPerson | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setLoading(true);
      const data = await getTieredList();
      setTierData(data);
    } catch (error) {
      logger.error('获取排行榜数据失败', error);
      toast.error('加载失败，请刷新重试');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handleCardClick = (person: TieredPerson) => {
    setRatePerson(person);
    setRateOpen(true);
  };

  const getTierGroup = (tier: number): TierGroup => {
    const found = tierData?.tiers.find((t: TierGroup) => t.tier === tier);
    if (found) return found;
    const tierName = (
      { 5: '夯', 4: '顶级', 3: '人上人', 2: 'NPC', 1: '拉' } as Record<number, string>
    )[tier] as TierGroup['tierName'];
    return { tier: tier as TierGroup['tier'], tierName, persons: [] };
  };

  return (
    <div className="space-y-6">
      <Toaster
        position="top-center"
        toastOptions={{
          classNames: {
            toast:
              'border-2 border-foreground shadow-hard rounded-none bg-background text-foreground',
          },
        }}
      />

      {/* 顶部标题区 */}
      <section className="text-center space-y-3 py-4">
        <div className="flex items-center justify-between max-w-5xl mx-auto">
          <div className="flex-1 text-left">
            <h1 className="font-heading font-black text-3xl md:text-4xl leading-tight text-foreground">
              从夯到拉
              <br className="sm:hidden" />
              <span className="text-tier-s">锐评25中所有老师</span>
            </h1>
            <p className="text-sm italic text-muted-foreground mt-2">
              「没有最夯，只有更拉」—— 匿名锐评，不服来辩
            </p>
          </div>
          <Button
            type="button"
            onClick={() => setAddOpen(true)}
            className="bg-primary text-primary-foreground border-2 border-foreground rounded-none shadow-hard hover:shadow-hard-lg hover:-translate-y-0.5 transition-all duration-150 font-heading font-bold"
            data-ai-section-type="button"
          >
            <Plus className="size-4" />
            添加人物
          </Button>
        </div>
      </section>

      {/* 五档排行区 */}
      <section className="space-y-4">
        {loading ? (
          <div className="flex items-center justify-center py-20 text-muted-foreground">
            <div className="flex flex-col items-center gap-3">
              <div className="w-8 h-8 border-4 border-foreground border-t-transparent animate-spin" />
              <span className="font-mono text-sm">加载中...</span>
            </div>
          </div>
        ) : (
          TIER_ORDER.map((tier) => {
            const group = getTierGroup(tier);
            const meta = TIER_META[tier];
            return (
              <TierBand
                key={tier}
                tierGroup={group}
                subtitle={meta.subtitle}
                emoji={meta.emoji}
                onCardClick={handleCardClick}
              />
            );
          })
        )}
      </section>

      {/* 待评分区 */}
      {!loading && tierData && (
        <section className="space-y-3 pt-4 border-t-2 border-foreground">
          <div className="flex items-baseline justify-between">
            <h2 className="font-heading font-black text-2xl text-foreground">
              待评分区
            </h2>
            <p className="text-sm italic text-muted-foreground">
              新晋人物，等待你的锐评
            </p>
          </div>
          {tierData.pending.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
              {tierData.pending.map((person: TieredPerson) => (
                <PersonCard
                  key={person.id}
                  person={person}
                  isPending
                  onClick={() => handleCardClick(person)}
                />
              ))}
            </div>
          ) : (
            <div className="border-2 border-foreground border-dashed bg-card p-8 text-center text-muted-foreground italic">
              暂无待评分人物，点击右上角「添加人物」来贡献第一位
            </div>
          )}
        </section>
      )}

      {/* 弹窗 */}
      <AddPersonDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        onSuccess={fetchData}
      />
      <RateDialog
        person={ratePerson}
        open={rateOpen}
        onOpenChange={setRateOpen}
        onSuccess={fetchData}
      />
    </div>
  );
};

export default HomePage;
