import PersonCard from './PersonCard';
import type { TierGroup, TieredPerson } from '@shared/api.interface';

interface TierBandProps {
  tierGroup: TierGroup;
  subtitle: string;
  emoji: string;
  onCardClick: (person: TieredPerson) => void;
}

const tierBgMap: Record<number, string> = {
  5: 'bg-tier-s text-tier-s-foreground',
  4: 'bg-tier-a text-tier-a-foreground',
  3: 'bg-tier-b text-tier-b-foreground',
  2: 'bg-tier-c text-tier-c-foreground',
  1: 'bg-tier-d text-tier-d-foreground',
};

const TierBand = ({ tierGroup, subtitle, emoji, onCardClick }: TierBandProps) => {
  const bgClass = tierBgMap[tierGroup.tier] || 'bg-tier-c text-tier-c-foreground';
  const hasPersons = tierGroup.persons.length > 0;

  return (
    <div className="border-2 border-foreground shadow-hard overflow-hidden">
      <div className="flex flex-col sm:flex-row">
        {/* 左侧档位标签 */}
        <div
          className={`${bgClass} sm:w-28 w-full sm:min-h-[160px] min-h-[60px] flex sm:flex-col flex-row items-center justify-center gap-1 p-3 border-b-2 sm:border-b-0 sm:border-r-2 border-foreground`}
        >
          <span className="text-2xl">{emoji}</span>
          <div className="text-center">
            <h3 className="font-heading font-black text-2xl sm:text-3xl leading-none">
              {tierGroup.tierName}
            </h3>
            <p className="text-xs italic opacity-80 mt-1">{subtitle}</p>
          </div>
        </div>

        {/* 右侧人物卡片 */}
        <div className="flex-1 p-3 bg-card">
          {hasPersons ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
              {tierGroup.persons.map((person: TieredPerson) => (
                <PersonCard
                  key={person.id}
                  person={person}
                  onClick={() => onCardClick(person)}
                />
              ))}
            </div>
          ) : (
            <div className="flex items-center justify-center h-24 text-muted-foreground text-sm italic">
              暂无人物
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TierBand;
