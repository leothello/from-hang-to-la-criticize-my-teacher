import { Link } from 'react-router-dom';
import { Image } from '@client/src/components/ui/image';
import type { TieredPerson } from '@shared/api.interface';

interface PersonCardProps {
  person: TieredPerson;
  isPending?: boolean;
  onClick?: () => void;
}

const PersonCard = ({ person, isPending, onClick }: PersonCardProps) => {
  const firstChar = person.name.charAt(0);

  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative bg-card border-2 border-foreground shadow-hard-sm hover:shadow-hard hover:-translate-y-1 transition-all duration-150 text-left p-3 w-full"
      data-ai-section-type="card-list"
    >
      {isPending && (
        <span className="absolute -top-2 -right-2 bg-like text-like-foreground text-xs font-bold px-2 py-0.5 border-2 border-foreground z-10">
          待评分
        </span>
      )}
      <div className="flex flex-col items-center gap-2">
        <div className="w-full aspect-square border-2 border-foreground overflow-hidden bg-muted">
          {person.avatarUrl ? (
            <Image
              src={person.avatarUrl}
              alt={person.name}
              width={120}
              height={120}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-tier-s text-tier-s-foreground font-heading font-black text-3xl">
              {firstChar}
            </div>
          )}
        </div>
        <div className="w-full">
          <p className="font-heading font-bold text-sm truncate text-foreground">
            {person.name}
          </p>
          <p className="text-xs text-muted-foreground font-mono">
            {person.ratingCount > 0
              ? `${person.avgScore?.toFixed(1)}分 · ${person.ratingCount}评`
              : '暂无评分'}
          </p>
        </div>
      </div>
    </button>
  );
};

export default PersonCard;
