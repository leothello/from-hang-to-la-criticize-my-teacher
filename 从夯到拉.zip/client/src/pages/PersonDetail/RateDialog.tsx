import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';
import type { TierScore, TierName } from '@shared/api.interface';
import { TIER_SCORE_MAP } from '@shared/api.interface';

interface RateDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  personName: string;
  onSubmit: (score: TierScore) => Promise<void>;
}

const TIER_OPTIONS: { name: TierName; score: TierScore; bg: string }[] = [
  { name: '夯', score: 5, bg: 'bg-tier-s text-tier-s-foreground' },
  { name: '顶级', score: 4, bg: 'bg-tier-a text-tier-a-foreground' },
  { name: '人上人', score: 3, bg: 'bg-tier-b text-tier-b-foreground' },
  { name: 'NPC', score: 2, bg: 'bg-tier-c text-tier-c-foreground' },
  { name: '拉', score: 1, bg: 'bg-tier-d text-tier-d-foreground' },
];

const RateDialog = ({ open, onOpenChange, personName, onSubmit }: RateDialogProps) => {
  const [selected, setSelected] = useState<TierScore | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!selected) return;
    setSubmitting(true);
    try {
      await onSubmit(selected);
      setSelected(null);
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenChange = (next: boolean) => {
    if (!submitting) {
      onOpenChange(next);
      if (!next) setSelected(null);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="bg-background border-2 border-foreground shadow-hard-lg rounded-none p-6 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading font-black text-2xl text-center">
            给 {personName} 打分
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col gap-3 py-4">
          {TIER_OPTIONS.map((option) => {
            const isSelected = selected === option.score;
            return (
              <button
                key={option.score}
                onClick={() => setSelected(option.score)}
                className={`w-full px-4 py-3 font-heading font-black text-lg border-2 transition-all ${
                  isSelected
                    ? `${option.bg} border-foreground shadow-hard -translate-y-0.5`
                    : 'bg-card text-foreground border-foreground/60 hover:border-foreground'
                }`}
              >
                {option.name}
                <span className="ml-2 text-sm font-mono opacity-70">
                  Tier {option.score}
                </span>
              </button>
            );
          })}
        </div>

        <DialogFooter className="flex flex-row justify-end gap-3">
          <button
            type="button"
            onClick={() => handleOpenChange(false)}
            disabled={submitting}
            className="px-4 py-2 font-heading font-bold bg-card text-foreground border-2 border-foreground shadow-hard-sm hover:bg-accent transition-colors"
          >
            取消
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!selected || submitting}
            className="px-6 py-2 font-heading font-black bg-primary text-primary-foreground border-2 border-foreground shadow-hard disabled:opacity-50 disabled:cursor-not-allowed transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
          >
            {submitting ? '提交中...' : '确认评分'}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default RateDialog;
