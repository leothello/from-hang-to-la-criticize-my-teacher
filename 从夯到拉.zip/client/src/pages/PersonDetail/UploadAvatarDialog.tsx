import { useState, useRef, useCallback } from 'react';
import { Upload, X, Image as ImageIcon, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { logger } from '@lark-apaas/client-toolkit/logger';
import { getDataloom } from '@lark-apaas/client-toolkit/dataloom';
import { getDefaultBucketId } from '@lark-apaas/client-toolkit/tools/storage';

import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';

interface UploadAvatarDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (imageUrl: string) => Promise<void>;
}

const MAX_SIZE = 1 * 1024 * 1024; // 1MB

const UploadAvatarDialog = ({ open, onOpenChange, onSubmit }: UploadAvatarDialogProps) => {
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [uploading, setUploading] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (!f) return;

    if (!f.type.startsWith('image/')) {
      toast.error('请选择图片文件');
      return;
    }
    if (f.size > MAX_SIZE) {
      toast.error('图片大小不能超过 1MB');
      return;
    }

    setFile(f);
    const url = URL.createObjectURL(f);
    setPreviewUrl(url);
  }, []);

  const clearFile = useCallback(() => {
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    setFile(null);
    setPreviewUrl(null);
    if (inputRef.current) inputRef.current.value = '';
  }, [previewUrl]);

  const handleSubmit = async () => {
    if (!file) return;
    setUploading(true);
    try {
      const dataloom = await getDataloom();
      const bucket = dataloom.storage.from(getDefaultBucketId());
      const result = await bucket.uploadFile(file);
      if (result.error) {
        throw result.error;
      }
      const imageUrl = result.data.download_url;
      await onSubmit(imageUrl);
      clearFile();
    } catch (error) {
      logger.error('上传头像失败', error);
      toast.error('上传失败，请稍后重试');
    } finally {
      setUploading(false);
    }
  };

  const handleOpenChange = (next: boolean) => {
    if (uploading) return;
    onOpenChange(next);
    if (!next) {
      clearFile();
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="bg-background border-2 border-foreground shadow-hard-lg rounded-none p-6 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading font-black text-2xl">
            上传新照片
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-2">
          {previewUrl ? (
            <div className="relative w-full aspect-square border-2 border-foreground shadow-hard-sm overflow-hidden bg-accent">
              <img
                src={previewUrl}
                alt="预览"
                className="w-full h-full object-cover"
              />
              <button
                type="button"
                onClick={clearFile}
                disabled={uploading}
                className="absolute top-2 right-2 p-1.5 bg-primary text-primary-foreground border-2 border-foreground shadow-hard-sm"
                aria-label="移除图片"
              >
                <X className="size-4" />
              </button>
            </div>
          ) : (
            <label className="flex flex-col items-center justify-center w-full aspect-square border-2 border-dashed border-foreground/60 bg-accent/50 cursor-pointer hover:bg-accent transition-colors">
              <ImageIcon className="size-10 text-muted-foreground mb-2" />
              <span className="font-heading font-bold text-foreground">
                点击选择图片
              </span>
              <span className="text-sm text-muted-foreground mt-1">
                支持 JPG / PNG，不超过 1MB
              </span>
              <input
                ref={inputRef}
                type="file"
                accept="image/*"
                onChange={handleFileChange}
                className="hidden"
              />
            </label>
          )}

          <p className="text-xs text-muted-foreground text-center">
            图片大小不超过 1MB，建议使用正方形头像
          </p>
        </div>

        <DialogFooter className="flex flex-row justify-end gap-3">
          <button
            type="button"
            onClick={() => handleOpenChange(false)}
            disabled={uploading}
            className="px-4 py-2 font-heading font-bold bg-card text-foreground border-2 border-foreground shadow-hard-sm hover:bg-accent transition-colors"
          >
            取消
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!file || uploading}
            className="inline-flex items-center gap-2 px-6 py-2 font-heading font-black bg-primary text-primary-foreground border-2 border-foreground shadow-hard disabled:opacity-50 disabled:cursor-not-allowed transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
          >
            {uploading ? (
              <>
                <Loader2 className="size-4 animate-spin" />
                上传中...
              </>
            ) : (
              <>
                <Upload className="size-4" />
                确认上传
              </>
            )}
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default UploadAvatarDialog;
