import { useEffect, useState, useCallback } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { toast } from 'sonner';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { logger } from '@lark-apaas/client-toolkit/logger';

import {
  getPersonDetail,
  getAvatars,
  getBios,
  ratePerson,
  createAvatar,
  createBio,
  likeAvatar,
  likeBio,
} from '@client/src/api/person';
import type {
  PersonDetailResponse,
  PersonAvatar,
  PersonBio,
  TierScore,
} from '@shared/api.interface';

import PersonHeader from './PersonHeader';
import AvatarGallery from './AvatarGallery';
import BioList from './BioList';
import RateDialog from './RateDialog';
import UploadAvatarDialog from './UploadAvatarDialog';
import AddBioDialog from './AddBioDialog';

const PersonDetailPage = () => {
  const { id = '' } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [loading, setLoading] = useState(true);
  const [person, setPerson] = useState<PersonDetailResponse | null>(null);
  const [avatars, setAvatars] = useState<PersonAvatar[]>([]);
  const [bios, setBios] = useState<PersonBio[]>([]);
  const [selectedAvatarId, setSelectedAvatarId] = useState<string | null>(null);

  const [rateOpen, setRateOpen] = useState(false);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [bioOpen, setBioOpen] = useState(false);

  const fetchAll = useCallback(async () => {
    if (!id) return;
    setLoading(true);
    try {
      const [detailRes, avatarsRes, biosRes] = await Promise.all([
        getPersonDetail(id),
        getAvatars(id),
        getBios(id),
      ]);
      setPerson(detailRes);
      setAvatars(avatarsRes.items);
      setBios(biosRes.items);
      if (avatarsRes.items.length > 0) {
        setSelectedAvatarId(avatarsRes.items[0].id);
      }
    } catch (error) {
      logger.error('加载人物详情失败', error);
      toast.error('加载失败，请稍后重试');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchAll();
  }, [fetchAll]);

  const handleRate = async (score: TierScore) => {
    if (!id) return;
    try {
      const res = await ratePerson(id, { score });
      setPerson((prev) =>
        prev
          ? {
              ...prev,
              avgScore: res.avgScore,
              ratingCount: res.ratingCount,
              tier: res.tier,
              tierName: res.tierName,
            }
          : prev,
      );
      toast.success('评分成功！');
      setRateOpen(false);
    } catch (error) {
      logger.error('评分失败', error);
      toast.error('评分失败，请稍后重试');
    }
  };

  const handleUploadAvatar = async (imageUrl: string) => {
    if (!id) return;
    try {
      const res = await createAvatar(id, { imageUrl });
      setAvatars((prev) => [
        { id: res.id, personId: id, imageUrl: res.imageUrl, likeCount: res.likeCount, createdAt: new Date().toISOString() },
        ...prev,
      ]);
      setSelectedAvatarId(res.id);
      toast.success('头像上传成功！');
      setUploadOpen(false);
    } catch (error) {
      logger.error('上传头像失败', error);
      toast.error('上传失败，请稍后重试');
    }
  };

  const handleAddBio = async (content: string) => {
    if (!id) return;
    try {
      const res = await createBio(id, { content });
      setBios((prev) => [
        { id: res.id, personId: id, content: res.content, likeCount: res.likeCount, createdAt: new Date().toISOString() },
        ...prev,
      ]);
      toast.success('简介添加成功！');
      setBioOpen(false);
    } catch (error) {
      logger.error('添加简介失败', error);
      toast.error('添加失败，请稍后重试');
    }
  };

  const handleLikeAvatar = async (avatarId: string) => {
    if (!id) return;
    try {
      const res = await likeAvatar(id, avatarId);
      setAvatars((prev) =>
        prev
          .map((a: PersonAvatar) =>
            a.id === avatarId ? { ...a, likeCount: res.likeCount } : a,
          )
          .sort((a: PersonAvatar, b: PersonAvatar) => b.likeCount - a.likeCount),
      );
    } catch (error) {
      logger.error('点赞头像失败', error);
      toast.error('点赞失败');
    }
  };

  const handleLikeBio = async (bioId: string) => {
    if (!id) return;
    try {
      const res = await likeBio(id, bioId);
      setBios((prev) =>
        prev
          .map((b: PersonBio) =>
            b.id === bioId ? { ...b, likeCount: res.likeCount } : b,
          )
          .sort((a: PersonBio, b: PersonBio) => b.likeCount - a.likeCount),
      );
    } catch (error) {
      logger.error('点赞简介失败', error);
      toast.error('点赞失败');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <Loader2 className="size-8 animate-spin text-foreground" />
        <p className="font-heading font-bold text-lg">加载中...</p>
      </div>
    );
  }

  if (!person) {
    return (
      <div className="flex flex-col items-center justify-center py-24 gap-4">
        <p className="font-heading font-bold text-xl">人物不存在</p>
        <button
          onClick={() => navigate('/')}
          className="inline-flex items-center gap-2 px-4 py-2 bg-primary text-primary-foreground font-heading font-bold border-2 border-foreground shadow-hard"
        >
          <ArrowLeft className="size-4" />
          返回排行榜
        </button>
      </div>
    );
  }

  const selectedAvatar = avatars.find((a: PersonAvatar) => a.id === selectedAvatarId) ?? null;
  const topBio = bios.length > 0 ? bios[0] : null;

  return (
    <div className="space-y-6">
      {/* 返回入口 */}
      <Link
        to="/"
        className="inline-flex items-center gap-2 font-heading font-bold text-sm hover:opacity-70 transition-opacity"
      >
        <ArrowLeft className="size-4" />
        返回排行榜
      </Link>

      {/* 人物信息头 */}
      <PersonHeader
        person={person}
        selectedAvatar={selectedAvatar}
        onRateClick={() => setRateOpen(true)}
      />

      {/* 头像墙 */}
      <AvatarGallery
        avatars={avatars}
        selectedAvatarId={selectedAvatarId}
        personName={person.name}
        onSelect={setSelectedAvatarId}
        onLike={handleLikeAvatar}
        onUploadClick={() => setUploadOpen(true)}
      />

      {/* 简介列表 */}
      <BioList
        bios={bios}
        topBioId={topBio?.id ?? null}
        onLike={handleLikeBio}
        onAddClick={() => setBioOpen(true)}
      />

      {/* 弹窗 */}
      <RateDialog
        open={rateOpen}
        onOpenChange={setRateOpen}
        personName={person.name}
        onSubmit={handleRate}
      />
      <UploadAvatarDialog
        open={uploadOpen}
        onOpenChange={setUploadOpen}
        onSubmit={handleUploadAvatar}
      />
      <AddBioDialog
        open={bioOpen}
        onOpenChange={setBioOpen}
        onSubmit={handleAddBio}
      />
    </div>
  );
};

export default PersonDetailPage;
