import { useState } from 'react';
import { Send } from 'lucide-react';
import { Textarea } from '@client/src/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@client/src/components/ui/dialog';

interface AddBioDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (content: string) => Promise<void>;
}

const MAX_LENGTH = 200;

const AddBioDialog = ({ open, onOpenChange, onSubmit }: AddBioDialogProps) => {
  const [content, setContent] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async () => {
    const trimmed = content.trim();
    if (!trimmed) return;
    setSubmitting(true);
    try {
      await onSubmit(trimmed);
      setContent('');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOpenChange = (next: boolean) => {
    if (submitting) return;
    onOpenChange(next);
    if (!next) setContent('');
  };

  const charCount = content.length;
  const isOverLimit = charCount > MAX_LENGTH;

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="bg-background border-2 border-foreground shadow-hard-lg rounded-none p-6 max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading font-black text-2xl">
            添加锐评简介
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-2 py-2">
          <Textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="写下你对这位老师的锐评..."
            maxLength={MAX_LENGTH + 50}
            rows={6}
            className={`rounded-none border-2 border-foreground bg-card font-sans text-base p-3 focus-visible:ring-0 focus-visible:border-foreground ${
              isOverLimit ? 'border-like text-like' : ''
            }`}
          />
          <div className="flex justify-end">
            <span
              className={`font-mono text-sm font-bold ${
                isOverLimit ? 'text-like' : 'text-muted-foreground'
              }`}
            >
              {charCount} / {MAX_LENGTH}
            </span>
          </div>
        </div>

        <DialogFooter className="flex flex-row justify-end gap-3">
          <button
            type="button"
            onClick={() => handleOpenChange(false)}
            disabled={submitting}
            className="px-4 py-2 font-heading font-bold bg-card text-foreground border-2 border-foreground shadow-hard-sm hover:bg-accent transition-colors"
          >
            取消
          </button>
          <button
            type="button"
            onClick={handleSubmit}
            disabled={!content.trim() || isOverLimit || submitting}
            className="inline-flex items-center gap-2 px-6 py-2 font-heading font-black bg-primary text-primary-foreground border-2 border-foreground shadow-hard disabled:opacity-50 disabled:cursor-not-allowed transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
          >
            <Send className="size-4" />
            提交
          </button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default AddBioDialog;
