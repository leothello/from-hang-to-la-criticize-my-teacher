import { Heart, Upload, ImageOff } from 'lucide-react';
import Image from '@client/src/components/ui/image';
import type { PersonAvatar } from '@shared/api.interface';

interface AvatarGalleryProps {
  avatars: PersonAvatar[];
  selectedAvatarId: string | null;
  personName: string;
  onSelect: (id: string) => void;
  onLike: (id: string) => void;
  onUploadClick: () => void;
}

const AvatarGallery = ({
  avatars,
  selectedAvatarId,
  personName,
  onSelect,
  onLike,
  onUploadClick,
}: AvatarGalleryProps) => {
  return (
    <section className="border-2 border-foreground shadow-hard bg-card">
      <div className="flex items-center justify-between p-4 border-b-2 border-foreground bg-accent">
        <h2 className="font-heading font-black text-xl">头像墙</h2>
        <button
          onClick={onUploadClick}
          className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground font-heading font-bold text-sm border-2 border-foreground shadow-hard-sm transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
        >
          <Upload className="size-4" />
          上传新照片
        </button>
      </div>

      <div className="p-4">
        {avatars.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3 text-muted-foreground">
            <ImageOff className="size-12 opacity-50" />
            <p className="font-heading font-bold">暂无头像，上传第一张吧</p>
          </div>
        ) : (
          <div className="flex gap-4 overflow-x-auto pb-2 -mx-1 px-1">
            {avatars.map((avatar: PersonAvatar) => {
              const isSelected = avatar.id === selectedAvatarId;
              return (
                <div
                  key={avatar.id}
                  className="flex-shrink-0 flex flex-col gap-2"
                >
                  <button
                    onClick={() => onSelect(avatar.id)}
                    className={`relative w-24 h-24 overflow-hidden transition-transform hover:-translate-y-0.5 ${
                      isSelected
                        ? 'border-4 border-tier-s shadow-hard'
                        : 'border-2 border-foreground shadow-hard-sm'
                    }`}
                    aria-label={`选择 ${personName} 的头像`}
                  >
                    <Image
                      src={avatar.imageUrl}
                      alt={personName}
                      width={96}
                      height={96}
                      className="w-full h-full object-cover"
                    />
                  </button>
                  <div className="flex items-center justify-between gap-2 px-1">
                    <span className="font-mono font-bold text-sm">
                      {avatar.likeCount}
                    </span>
                    <button
                      onClick={() => onLike(avatar.id)}
                      className="inline-flex items-center justify-center p-1 text-foreground hover:text-like transition-colors"
                      aria-label="点赞"
                    >
                      <Heart className="size-4" strokeWidth={2.5} />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
};

export default AvatarGallery;
