import { Star } from 'lucide-react';
import Image from '@client/src/components/ui/image';
import type { PersonDetailResponse, PersonAvatar } from '@shared/api.interface';
import { SCORE_TIER_MAP } from '@shared/api.interface';

interface PersonHeaderProps {
  person: PersonDetailResponse;
  selectedAvatar: PersonAvatar | null;
  onRateClick: () => void;
}

const TIER_BG: Record<number, string> = {
  5: 'bg-tier-s text-tier-s-foreground',
  4: 'bg-tier-a text-tier-a-foreground',
  3: 'bg-tier-b text-tier-b-foreground',
  2: 'bg-tier-c text-tier-c-foreground',
  1: 'bg-tier-d text-tier-d-foreground',
};

const PersonHeader = ({ person, selectedAvatar, onRateClick }: PersonHeaderProps) => {
  const tier = person.tier;
  const tierName = person.tierName ?? (tier ? SCORE_TIER_MAP[tier] : null);
  const tierClass = tier ? TIER_BG[tier] : 'bg-muted text-muted-foreground';
  const avatarUrl = selectedAvatar?.imageUrl ?? person.defaultAvatar?.imageUrl ?? null;
  const initial = person.name.charAt(0);

  return (
    <section className="flex flex-col sm:flex-row gap-6 p-6 bg-card border-2 border-foreground shadow-hard">
      {/* 左侧：大头像 */}
      <div className="flex-shrink-0 mx-auto sm:mx-0">
        <div className="w-40 h-40 sm:w-48 sm:h-48 border-2 border-foreground shadow-hard overflow-hidden bg-accent">
          {avatarUrl ? (
            <Image
              src={avatarUrl}
              alt={person.name}
              width={192}
              height={192}
              className="w-full h-full object-cover"
            />
          ) : (
            <div
              className={`w-full h-full flex items-center justify-center font-heading font-black text-6xl ${tierClass}`}
            >
              {initial}
            </div>
          )}
        </div>
      </div>

      {/* 右侧：信息 */}
      <div className="flex-1 flex flex-col gap-4">
        <div className="flex flex-wrap items-start gap-3">
          <h1 className="font-heading font-black text-3xl sm:text-4xl leading-none">
            {person.name}
          </h1>
          {tierName && (
            <span
              className={`inline-flex items-center gap-1 px-3 py-1 font-heading font-black text-sm border-2 border-foreground shadow-hard-sm ${tierClass}`}
            >
              {tierName}
              <span className="text-xs opacity-70">Tier {tier}</span>
            </span>
          )}
          {person.isPending && (
            <span className="inline-flex items-center px-3 py-1 font-heading font-bold text-xs bg-muted text-muted-foreground border-2 border-foreground">
              待审核
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-baseline gap-6">
          <div className="flex items-baseline gap-2">
            <span className="font-mono font-bold text-4xl text-foreground">
              {person.avgScore !== null ? person.avgScore.toFixed(1) : '—'}
            </span>
            <span className="font-heading font-bold text-sm text-muted-foreground">
              平均分
            </span>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="font-mono font-bold text-2xl text-foreground">
              {person.ratingCount}
            </span>
            <span className="font-heading font-bold text-sm text-muted-foreground">
              人评分
            </span>
          </div>
        </div>

        <div className="mt-auto pt-2">
          <button
            onClick={onRateClick}
            className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-heading font-black text-lg border-2 border-foreground shadow-hard transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
          >
            <Star className="size-5" />
            我要评分
          </button>
        </div>
      </div>
    </section>
  );
};

export default PersonHeader;
