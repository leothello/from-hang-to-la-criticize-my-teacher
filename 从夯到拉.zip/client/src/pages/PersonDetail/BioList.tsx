import { Heart, Plus, MessageSquareOff } from 'lucide-react';
import type { PersonBio } from '@shared/api.interface';

interface BioListProps {
  bios: PersonBio[];
  topBioId: string | null;
  onLike: (id: string) => void;
  onAddClick: () => void;
}

const BioList = ({ bios, topBioId, onLike, onAddClick }: BioListProps) => {
  return (
    <section className="border-2 border-foreground shadow-hard bg-card">
      <div className="flex items-center justify-between p-4 border-b-2 border-foreground bg-accent">
        <h2 className="font-heading font-black text-xl">锐评简介</h2>
        <button
          onClick={onAddClick}
          className="inline-flex items-center gap-2 px-3 py-1.5 bg-primary text-primary-foreground font-heading font-bold text-sm border-2 border-foreground shadow-hard-sm transition-transform hover:-translate-y-0.5 active:translate-y-0 active:shadow-none"
        >
          <Plus className="size-4" />
          添加简介
        </button>
      </div>

      <div className="p-4 space-y-4">
        {bios.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 gap-3 text-muted-foreground">
            <MessageSquareOff className="size-12 opacity-50" />
            <p className="font-heading font-bold">暂无简介，来写第一条吧</p>
          </div>
        ) : (
          bios.map((bio: PersonBio) => {
            const isTop = bio.id === topBioId;
            return (
              <div
                key={bio.id}
                className={`p-4 border-2 shadow-hard-sm bg-background ${
                  isTop ? 'border-tier-s ring-2 ring-tier-s/30' : 'border-foreground'
                }`}
              >
                <p className="font-sans text-base leading-relaxed whitespace-pre-wrap break-words">
                  {bio.content}
                </p>
                <div className="flex items-center justify-end gap-2 mt-3 pt-3 border-t border-foreground/20">
                  <span className="font-mono font-bold text-sm">
                    {bio.likeCount}
                  </span>
                  <button
                    onClick={() => onLike(bio.id)}
                    className="inline-flex items-center justify-center p-1 text-foreground hover:text-like transition-colors"
                    aria-label="点赞简介"
                  >
                    <Heart className="size-4" strokeWidth={2.5} />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </section>
  );
};

export default BioList;
