import { logger } from '@lark-apaas/client-toolkit/logger';
import { axiosForBackend } from '@lark-apaas/client-toolkit/utils/getAxiosForBackend';

import type {
  TieredListResponse,
  PersonDetailResponse,
  AvatarListResponse,
  BioListResponse,
  CreatePersonRequest,
  CreatePersonResponse,
  RatePersonRequest,
  RatePersonResponse,
  CreateAvatarRequest,
  CreateAvatarResponse,
  CreateBioRequest,
  CreateBioResponse,
  LikeResponse,
} from '@shared/api.interface';

export async function getTieredList(): Promise<TieredListResponse> {
  try {
    const res = await axiosForBackend.get<TieredListResponse>('/api/persons/tiered');
    return res.data;
  } catch (error) {
    logger.error('获取档位人物列表失败', error);
    throw error;
  }
}

export async function getPersonDetail(id: string): Promise<PersonDetailResponse> {
  try {
    const res = await axiosForBackend.get<PersonDetailResponse>(`/api/persons/${id}`);
    return res.data;
  } catch (error) {
    logger.error(`获取人物详情失败: ${id}`, error);
    throw error;
  }
}

export async function createPerson(
  data: CreatePersonRequest,
): Promise<CreatePersonResponse> {
  try {
    const res = await axiosForBackend.post<CreatePersonResponse>(
      '/api/persons',
      data,
    );
    return res.data;
  } catch (error) {
    logger.error('创建人物失败', error);
    throw error;
  }
}

export async function ratePerson(
  id: string,
  data: RatePersonRequest,
): Promise<RatePersonResponse> {
  try {
    const res = await axiosForBackend.post<RatePersonResponse>(
      `/api/persons/${id}/rate`,
      data,
    );
    return res.data;
  } catch (error) {
    logger.error(`评分失败: ${id}`, error);
    throw error;
  }
}

export async function getAvatars(personId: string): Promise<AvatarListResponse> {
  try {
    const res = await axiosForBackend.get<AvatarListResponse>(
      `/api/persons/${personId}/avatars`,
    );
    return res.data;
  } catch (error) {
    logger.error(`获取头像列表失败: ${personId}`, error);
    throw error;
  }
}

export async function createAvatar(
  personId: string,
  data: CreateAvatarRequest,
): Promise<CreateAvatarResponse> {
  try {
    const res = await axiosForBackend.post<CreateAvatarResponse>(
      `/api/persons/${personId}/avatars`,
      data,
    );
    return res.data;
  } catch (error) {
    logger.error(`创建头像失败: ${personId}`, error);
    throw error;
  }
}

export async function likeAvatar(
  personId: string,
  avatarId: string,
): Promise<LikeResponse> {
  try {
    const res = await axiosForBackend.post<LikeResponse>(
      `/api/persons/${personId}/avatars/${avatarId}/like`,
    );
    return res.data;
  } catch (error) {
    logger.error(`点赞头像失败: ${avatarId}`, error);
    throw error;
  }
}

export async function getBios(personId: string): Promise<BioListResponse> {
  try {
    const res = await axiosForBackend.get<BioListResponse>(
      `/api/persons/${personId}/bios`,
    );
    return res.data;
  } catch (error) {
    logger.error(`获取简介列表失败: ${personId}`, error);
    throw error;
  }
}

export async function createBio(
  personId: string,
  data: CreateBioRequest,
): Promise<CreateBioResponse> {
  try {
    const res = await axiosForBackend.post<CreateBioResponse>(
      `/api/persons/${personId}/bios`,
      data,
    );
    return res.data;
  } catch (error) {
    logger.error(`创建简介失败: ${personId}`, error);
    throw error;
  }
}

export async function likeBio(
  personId: string,
  bioId: string,
): Promise<LikeResponse> {
  try {
    const res = await axiosForBackend.post<LikeResponse>(
      `/api/persons/${personId}/bios/${bioId}/like`,
    );
    return res.data;
  } catch (error) {
    logger.error(`点赞简介失败: ${bioId}`, error);
    throw error;
  }
}
