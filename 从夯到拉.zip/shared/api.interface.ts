export const TIER_SCORE_MAP = {
  夯: 5,
  顶级: 4,
  人上人: 3,
  NPC: 2,
  拉: 1,
} as const;

export const SCORE_TIER_MAP = {
  5: '夯',
  4: '顶级',
  3: '人上人',
  2: 'NPC',
  1: '拉',
} as const;

export type TierScore = 1 | 2 | 3 | 4 | 5;
export type TierName = '夯' | '顶级' | '人上人' | 'NPC' | '拉';

export interface Person {
  id: string;
  name: string;
  avgScore: number | null;
  ratingCount: number;
  isPending: boolean;
  tier: TierScore | null;
  defaultAvatarUrl: string | null;
  defaultBio: string | null;
  createdAt: string;
}

export interface PersonAvatar {
  id: string;
  personId: string;
  imageUrl: string;
  likeCount: number;
  createdAt: string;
}

export interface PersonBio {
  id: string;
  personId: string;
  content: string;
  likeCount: number;
  createdAt: string;
}

export interface PersonRating {
  id: string;
  personId: string;
  score: TierScore;
  createdAt: string;
}

export interface TieredPerson {
  id: string;
  name: string;
  avgScore: number | null;
  ratingCount: number;
  avatarUrl: string | null;
}

export interface TierGroup {
  tier: TierScore;
  tierName: TierName;
  persons: TieredPerson[];
}

export interface TieredListResponse {
  tiers: TierGroup[];
  pending: TieredPerson[];
}

export interface PersonDetailResponse {
  id: string;
  name: string;
  avgScore: number | null;
  ratingCount: number;
  tier: TierScore | null;
  tierName: TierName | null;
  isPending: boolean;
  defaultAvatar: PersonAvatar | null;
  defaultBio: PersonBio | null;
}

export interface AvatarListResponse {
  items: PersonAvatar[];
}

export interface BioListResponse {
  items: PersonBio[];
}

export interface CreatePersonRequest {
  name: string;
  bio: string;
  imageUrl?: string;
}

export interface CreatePersonResponse {
  id: string;
  name: string;
  isPending: boolean;
}

export interface RatePersonRequest {
  score: TierScore;
}

export interface RatePersonResponse {
  id: string;
  avgScore: number;
  ratingCount: number;
  tier: TierScore;
  tierName: TierName;
}

export interface CreateAvatarRequest {
  imageUrl: string;
}

export interface CreateAvatarResponse {
  id: string;
  imageUrl: string;
  likeCount: number;
}

export interface CreateBioRequest {
  content: string;
}

export interface CreateBioResponse {
  id: string;
  content: string;
  likeCount: number;
}

export interface LikeResponse {
  id: string;
  likeCount: number;
}
