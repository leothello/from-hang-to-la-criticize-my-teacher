const API = '/api';

let persons = [];
let currentPersonId = null;
let currentDetail = null;
let currentProfileIndex = 0;
let confirmCallback = null;

// 用户唯一ID
function getUserId() {
    let id = localStorage.getItem('tr_user_id');
    if (!id) {
        id = 'u_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('tr_user_id', id);
    }
    return id;
}
const USER_ID = getUserId();

// 屏蔽列表
function getBlockedIds() {
    try { return JSON.parse(localStorage.getItem('tr_blocked') || '[]'); }
    catch (e) { return []; }
}
function addBlockedId(id) {
    const list = getBlockedIds();
    if (!list.includes(id)) {
        list.push(parseInt(id));
        localStorage.setItem('tr_blocked', JSON.stringify(list));
    }
}
function removeBlockedId(id) {
    let list = getBlockedIds();
    list = list.filter(x => x !== parseInt(id));
    localStorage.setItem('tr_blocked', JSON.stringify(list));
}
function isBlocked(id) {
    return getBlockedIds().includes(parseInt(id));
}

// 已申请下架列表
function getReportedIds() {
    try { return JSON.parse(localStorage.getItem('tr_reported') || '[]'); }
    catch (e) { return []; }
}
function addReportedId(id) {
    const list = getReportedIds();
    if (!list.includes(id)) {
        list.push(parseInt(id));
        localStorage.setItem('tr_reported', JSON.stringify(list));
    }
}

// DOM 元素
const welcomeModal = document.getElementById('welcomeModal');
const addModal = document.getElementById('addModal');
const rateModal = document.getElementById('rateModal');
const detailModal = document.getElementById('detailModal');
const profileModal = document.getElementById('profileModal');
const confirmModal = document.getElementById('confirmModal');
const toast = document.getElementById('toast');

// 初始化
init();

function init() {
    if (!localStorage.getItem('tr_welcomed')) {
        openModal(welcomeModal);
    }
    loadPersons();
}

// 欢迎弹窗
document.getElementById('welcomeBtn').addEventListener('click', () => {
    localStorage.setItem('tr_welcomed', '1');
    closeModal(welcomeModal);
});

// 事件监听
document.getElementById('addBtn').addEventListener('click', () => openModal(addModal));
document.getElementById('closeAdd').addEventListener('click', () => closeModal(addModal));
document.getElementById('closeRate').addEventListener('click', () => closeModal(rateModal));
document.getElementById('closeDetail').addEventListener('click', () => closeModal(detailModal));
document.getElementById('closeProfile').addEventListener('click', () => closeModal(profileModal));
document.getElementById('closeConfirm').addEventListener('click', () => closeModal(confirmModal));

[welcomeModal, addModal, rateModal, detailModal, profileModal, confirmModal].forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) closeModal(m); });
});

// 确认弹窗
document.getElementById('confirmYes').addEventListener('click', () => {
    closeModal(confirmModal);
    if (confirmCallback) confirmCallback(true);
});
document.getElementById('confirmNo').addEventListener('click', () => {
    closeModal(confirmModal);
    if (confirmCallback) confirmCallback(false);
});

function showConfirm(title, body, callback) {
    document.getElementById('confirmTitle').textContent = title;
    document.getElementById('confirmBody').textContent = body;
    confirmCallback = callback;
    openModal(confirmModal);
}

// 添加人物表单
document.getElementById('addForm').addEventListener('submit', async e => {
    e.preventDefault();
    const name = document.getElementById('personName').value.trim();
    const bio = document.getElementById('personBio').value.trim();

    if (!name || !bio) { showToast('姓名和简介必须填写'); return; }
    if (bio.length > 200) { showToast('简介不能超过200字'); return; }

    try {
        const res = await fetch(API + '/persons', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ name, bio, uploader_id: USER_ID })
        });
        const data = await res.json();
        if (!res.ok) { showToast(data.error || '添加失败'); return; }
        showToast('添加成功');
        closeModal(addModal);
        document.getElementById('addForm').reset();
        document.getElementById('charCount').textContent = '0';
        loadPersons();
    } catch (err) {
        showToast('网络错误');
    }
});

// 字数统计
document.getElementById('personBio').addEventListener('input', e => {
    document.getElementById('charCount').textContent = e.target.value.length;
});
document.getElementById('profileBio').addEventListener('input', e => {
    document.getElementById('profileCharCount').textContent = e.target.value.length;
});

// 评分按钮
document.querySelectorAll('.rate-btn').forEach(btn => {
    btn.addEventListener('click', async () => {
        const rating = parseInt(btn.dataset.value);
        try {
            const res = await fetch(API + '/persons/' + currentPersonId + '/rate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ rating })
            });
            const data = await res.json();
            if (!res.ok) { showToast(data.error || '评分失败'); return; }
            showToast('评分成功');
            closeModal(rateModal);
            loadPersons();
        } catch (err) {
            showToast('网络错误');
        }
    });
});

// 上传新资料
document.getElementById('addProfileBtn').addEventListener('click', () => {
    closeModal(detailModal);
    document.getElementById('profileName').textContent = currentDetail?.name || '';
    openModal(profileModal);
});

document.getElementById('profileForm').addEventListener('submit', async e => {
    e.preventDefault();
    const bio = document.getElementById('profileBio').value.trim();

    if (!bio) { showToast('简介必须填写'); return; }
    if (bio.length > 200) { showToast('简介不能超过200字'); return; }

    try {
        const res = await fetch(API + '/persons/' + currentPersonId + '/profiles', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ bio })
        });
        const data = await res.json();
        if (!res.ok) { showToast(data.error || '上传失败'); return; }
        showToast('上传成功');
        closeModal(profileModal);
        document.getElementById('profileForm').reset();
        document.getElementById('profileCharCount').textContent = '0';
        loadPersons();
    } catch (err) {
        showToast('网络错误');
    }
});

// 点赞
document.getElementById('likeBtn').addEventListener('click', async () => {
    if (!currentDetail || !currentDetail.profiles[currentProfileIndex]) return;
    const profileId = currentDetail.profiles[currentProfileIndex].id;
    try {
        const res = await fetch(API + '/profiles/' + profileId + '/like', { method: 'POST' });
        if (!res.ok) { showToast('点赞失败'); return; }
        showToast('点赞成功');
        currentDetail.profiles[currentProfileIndex].likes++;
        renderDetail();
    } catch (err) {
        showToast('网络错误');
    }
});

// 删除（上传者真正删除）
document.getElementById('deleteBtn').addEventListener('click', () => {
    if (!currentDetail) return;
    showConfirm('删除人物', '确定要删除「' + currentDetail.name + '」吗？此操作不可恢复，所有人将无法再看到该人物。', async confirmed => {
        if (!confirmed) return;
        try {
            const res = await fetch(API + '/persons/' + currentPersonId, { method: 'DELETE' });
            if (!res.ok) { showToast('删除失败'); return; }
            showToast('已删除');
            closeModal(detailModal);
            loadPersons();
        } catch (err) {
            showToast('网络错误');
        }
    });
});

// 屏蔽（非上传者仅自己看不见）
document.getElementById('blockBtn').addEventListener('click', () => {
    if (!currentDetail) return;
    const blocked = isBlocked(currentPersonId);
    if (blocked) {
        removeBlockedId(currentPersonId);
        showToast('已取消屏蔽');
        renderDetail();
        loadPersons();
    } else {
        showConfirm('屏蔽人物', '屏蔽后，「' + currentDetail.name + '」将不会在你的设备上显示，但其他人仍可正常看到。确定屏蔽吗？', confirmed => {
            if (!confirmed) return;
            addBlockedId(currentPersonId);
            showToast('已屏蔽');
            closeModal(detailModal);
            loadPersons();
        });
    }
});

// 申请下架
document.getElementById('reportBtn').addEventListener('click', () => {
    if (!currentDetail) return;
    if (getReportedIds().includes(parseInt(currentPersonId))) {
        showToast('你已经申请过下架了');
        return;
    }
    showConfirm('申请下架', '申请下架「' + currentDetail.name + '」。当申请人数达到10人时，该人物将被删除。确定申请吗？', async confirmed => {
        if (!confirmed) return;
        try {
            const res = await fetch(API + '/persons/' + currentPersonId + '/removal', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ requester_id: USER_ID })
            });
            const data = await res.json();
            if (!res.ok) { showToast(data.error || '申请失败'); return; }
            addReportedId(parseInt(currentPersonId));
            if (data.removed) {
                showToast('该人物已被下架删除');
                closeModal(detailModal);
            } else {
                showToast('申请下架成功（' + data.count + '/10）');
                currentDetail.removalCount = data.count;
                renderDetail();
            }
            loadPersons();
        } catch (err) {
            showToast('网络错误');
        }
    });
});

// 加载人物列表
async function loadPersons() {
    try {
        const res = await fetch(API + '/persons');
        persons = await res.json();
        renderPersons();
    } catch (err) {
        showToast('加载数据失败');
    }
}

// 渲染人物
function renderPersons() {
    for (let i = 1; i <= 5; i++) {
        document.getElementById('tier-' + i).innerHTML = '';
    }
    document.getElementById('pendingList').innerHTML = '';

    persons.forEach(p => {
        if (isBlocked(p.id)) return;

        const card = createPersonCard(p);
        const rounded = Math.round(p.avg_rating || 0);

        if (p.avg_rating > 0 && rounded >= 1 && rounded <= 5) {
            const container = document.getElementById('tier-' + rounded);
            container.appendChild(card);
        } else {
            document.getElementById('pendingList').appendChild(card);
        }
    });

    for (let i = 1; i <= 5; i++) {
        const container = document.getElementById('tier-' + i);
        if (container.children.length === 0) {
            container.innerHTML = '<div class="tier-empty">暂无人物</div>';
        }
    }
}

function createPersonCard(p) {
    const div = document.createElement('div');
    div.className = 'person-card';
    div.innerHTML = `
        <div class="card-img">${escapeHtml(p.name)}</div>
        <div class="card-name">${escapeHtml(p.name)}</div>
    `;

    div.addEventListener('click', () => {
        if (p.avg_rating > 0) {
            openDetail(p.id);
        } else {
            openRate(p.id, p.name);
        }
    });

    return div;
}

// 打开评分弹窗
function openRate(id, name) {
    currentPersonId = id;
    document.getElementById('rateName').textContent = name;
    openModal(rateModal);
}

// 打开详情弹窗
async function openDetail(id) {
    currentPersonId = id;
    currentProfileIndex = 0;
    try {
        const res = await fetch(API + '/persons/' + id);
        currentDetail = await res.json();
        if (!res.ok) { showToast('加载详情失败'); return; }
        renderDetail();
        openModal(detailModal);
    } catch (err) {
        showToast('网络错误');
    }
}

function renderDetail() {
    if (!currentDetail) return;
    document.getElementById('detailName').textContent = currentDetail.name;

    const profiles = currentDetail.profiles || [];
    const profile = profiles[currentProfileIndex] || profiles[0];

    // 简介
    document.getElementById('detailBio').textContent = profile ? profile.bio : '暂无简介';

    // 简介切换导航
    const bioNav = document.getElementById('bioNav');
    bioNav.innerHTML = '';
    profiles.forEach((prof, idx) => {
        const btn = document.createElement('button');
        btn.className = 'nav-version' + (idx === currentProfileIndex ? ' active' : '');
        btn.textContent = `简介${idx + 1}`;
        btn.addEventListener('click', () => { currentProfileIndex = idx; renderDetail(); });
        bioNav.appendChild(btn);
    });

    // 按钮状态
    const isUploader = currentDetail.uploader_id === USER_ID;
    const deleteBtn = document.getElementById('deleteBtn');
    const blockBtn = document.getElementById('blockBtn');
    const reportBtn = document.getElementById('reportBtn');

    if (isUploader) {
        deleteBtn.style.display = 'block';
        deleteBtn.textContent = '🗑️ 删除';
        blockBtn.style.display = 'none';
    } else {
        deleteBtn.style.display = 'none';
        blockBtn.style.display = 'block';
        const blocked = isBlocked(currentPersonId);
        blockBtn.textContent = blocked ? '✓ 已屏蔽（点击取消）' : '🚫 屏蔽';
        blockBtn.classList.toggle('blocked', blocked);
    }

    // 申请下架按钮状态
    const reported = getReportedIds().includes(parseInt(currentPersonId));
    reportBtn.innerHTML = reported
        ? '✓ 已申请下架'
        : `⚠️ 申请下架 (<span id="reportCount">${currentDetail.removalCount || 0}</span>/10)`;
    reportBtn.classList.toggle('reported', reported);
    reportBtn.disabled = reported;

    // 统计
    const stats = document.getElementById('detailStats');
    const tierNames = { 1: '拉', 2: 'NPC', 3: '人上人', 4: '顶级', 5: '夯' };
    const rounded = Math.round(currentDetail.avgRating || 0);
    stats.innerHTML = `当前档位：${tierNames[rounded] || '待分档'} · ${currentDetail.ratingCount || 0} 人评分`;
}

// 弹窗控制
function openModal(m) { m.classList.add('active'); }
function closeModal(m) { m.classList.remove('active'); }

// 提示
function showToast(msg) {
    toast.textContent = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2500);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}
