const express = require('express');
const { kv } = require('@vercel/kv');

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// CORS
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET, POST, DELETE, OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type');
    if (req.method === 'OPTIONS') return res.sendStatus(200);
    next();
});

function generateId() {
    return Date.now() + Math.floor(Math.random() * 1000);
}

// ========== 辅助函数 ==========

async function getPersons() {
    return (await kv.get('persons')) || [];
}

async function savePersons(persons) {
    await kv.set('persons', persons);
}

async function getProfiles(personId) {
    return (await kv.get(`profiles:${personId}`)) || [];
}

async function saveProfiles(personId, profiles) {
    await kv.set(`profiles:${personId}`, profiles);
}

async function getRatings(personId) {
    return (await kv.get(`ratings:${personId}`)) || [];
}

async function saveRatings(personId, ratings) {
    await kv.set(`ratings:${personId}`, ratings);
}

async function getRemovals(personId) {
    return (await kv.get(`removals:${personId}`)) || [];
}

async function saveRemovals(personId, removals) {
    await kv.set(`removals:${personId}`, removals);
}

function sortProfiles(profiles) {
    return [...profiles].sort((a, b) => {
        if (b.likes !== a.likes) return b.likes - a.likes;
        return new Date(a.created_at) - new Date(b.created_at);
    });
}

function pickDefaultProfile(profiles) {
    if (!profiles || profiles.length === 0) return null;
    return sortProfiles(profiles)[0];
}

// ========== API 路由 ==========

// 获取所有人物
app.get('/api/persons', async (req, res) => {
    try {
        const persons = await getPersons();
        const result = [];
        for (const p of persons) {
            const profiles = await getProfiles(p.id);
            const ratings = await getRatings(p.id);
            const removals = await getRemovals(p.id);

            const avgRating = ratings.length > 0
                ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
                : 0;

            const defaultProfile = pickDefaultProfile(profiles);

            result.push({
                id: p.id,
                name: p.name,
                uploader_id: p.uploader_id,
                avg_rating: avgRating,
                rating_count: ratings.length,
                removal_count: removals.length,
                bio: defaultProfile ? defaultProfile.bio : null
            });
        }
        res.json(result);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 获取单个人物详情
app.get('/api/persons/:id', async (req, res) => {
    try {
        const personId = parseInt(req.params.id);
        const persons = await getPersons();
        const person = persons.find(p => p.id === personId);
        if (!person) return res.status(404).json({ error: '人物不存在' });

        const profiles = sortProfiles(await getProfiles(personId));
        const ratings = await getRatings(personId);
        const removals = await getRemovals(personId);

        const avgRating = ratings.length > 0
            ? ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length
            : 0;

        res.json({
            ...person,
            profiles,
            avgRating,
            ratingCount: ratings.length,
            removalCount: removals.length
        });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 添加新人物
app.post('/api/persons', async (req, res) => {
    try {
        const { name, bio, uploader_id } = req.body;
        if (!name || !bio || !uploader_id) {
            return res.status(400).json({ error: '姓名、简介和上传者ID必须填写' });
        }
        if (bio.length > 200) return res.status(400).json({ error: '简介不能超过200字' });

        const persons = await getPersons();
        if (persons.some(p => p.name === name)) {
            return res.status(409).json({ error: '该人物已存在，不能重复添加' });
        }

        const newPerson = {
            id: generateId(),
            name,
            uploader_id,
            created_at: new Date().toISOString()
        };
        persons.push(newPerson);
        await savePersons(persons);

        const newProfile = {
            id: generateId(),
            bio,
            likes: 0,
            created_at: new Date().toISOString()
        };
        await saveProfiles(newPerson.id, [newProfile]);

        res.json({ id: newPerson.id, name, message: '添加成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 为已有人物添加新资料
app.post('/api/persons/:id/profiles', async (req, res) => {
    try {
        const personId = parseInt(req.params.id);
        const { bio } = req.body;
        if (!bio) return res.status(400).json({ error: '简介必须填写' });
        if (bio.length > 200) return res.status(400).json({ error: '简介不能超过200字' });

        let profiles = await getProfiles(personId);

        if (profiles.length >= 10) {
            profiles.sort((a, b) => {
                if (a.likes !== b.likes) return a.likes - b.likes;
                return new Date(a.created_at) - new Date(b.created_at);
            });
            profiles.shift();
        }

        const newProfile = {
            id: generateId(),
            bio,
            likes: 0,
            created_at: new Date().toISOString()
        };
        profiles.push(newProfile);
        await saveProfiles(personId, profiles);

        res.json({ id: newProfile.id, message: '资料添加成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 点赞
app.post('/api/profiles/:id/like', async (req, res) => {
    try {
        const profileId = req.params.id;
        const persons = await getPersons();

        for (const p of persons) {
            let profiles = await getProfiles(p.id);
            const idx = profiles.findIndex(prof => prof.id.toString() === profileId.toString());
            if (idx !== -1) {
                profiles[idx].likes++;
                await saveProfiles(p.id, profiles);
                return res.json({ message: '点赞成功' });
            }
        }
        res.status(404).json({ error: '简介不存在' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 评分
app.post('/api/persons/:id/rate', async (req, res) => {
    try {
        const personId = parseInt(req.params.id);
        const { rating } = req.body;
        if (!rating || rating < 1 || rating > 5) return res.status(400).json({ error: '评分必须在1-5之间' });

        const ratings = await getRatings(personId);
        ratings.push({
            id: generateId(),
            rating,
            created_at: new Date().toISOString()
        });
        await saveRatings(personId, ratings);

        const avgRating = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length;
        res.json({ avgRating, ratingCount: ratings.length, rounded: Math.round(avgRating) });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 删除人物
app.delete('/api/persons/:id', async (req, res) => {
    try {
        const personId = parseInt(req.params.id);
        let persons = await getPersons();
        persons = persons.filter(p => p.id !== personId);
        await savePersons(persons);

        await kv.del(`profiles:${personId}`);
        await kv.del(`ratings:${personId}`);
        await kv.del(`removals:${personId}`);

        res.json({ message: '删除成功' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 申请下架
app.post('/api/persons/:id/removal', async (req, res) => {
    try {
        const personId = parseInt(req.params.id);
        const { requester_id } = req.body;
        if (!requester_id) return res.status(400).json({ error: '缺少请求者ID' });

        const removals = await getRemovals(personId);
        if (removals.some(r => r.requester_id === requester_id)) {
            return res.status(409).json({ error: '你已经申请过下架了' });
        }

        removals.push({
            id: generateId(),
            requester_id,
            created_at: new Date().toISOString()
        });
        await saveRemovals(personId, removals);

        const count = removals.length;
        if (count >= 10) {
            let persons = await getPersons();
            persons = persons.filter(p => p.id !== personId);
            await savePersons(persons);

            await kv.del(`profiles:${personId}`);
            await kv.del(`ratings:${personId}`);
            await kv.del(`removals:${personId}`);

            res.json({ message: '该人物已被下架删除', removed: true, count });
        } else {
            res.json({ message: '申请下架成功', removed: false, count });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: err.message });
    }
});

// 导出给 Vercel
module.exports = app;

// 本地开发时直接启动
if (require.main === module) {
    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
}
